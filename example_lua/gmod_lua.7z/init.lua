include("libs/extensions/hooks.lua")
include("libs/interfaces.lua")
include("libs/wrapper.lua")
include("libs/enums.lua")
include("libs/extensions/timer.lua")

surface.CreateFont('ExampleFont', {
	size = 30,
	outline = true
})

surface.GetSchemeFont('SchemeFont', {
	res = 'ClientScheme', -- garrysmod/resource/ClientScheme.res
	font = 'Default'
})

--print(iEngine:GetScreenSize().x, iEngine:GetScreenSize().y)
--iUtil:LocalPlayer():Nick()

--hook.Add("Paint", "TEST", function(vguiPanel)
--	print(type(vguiPanel), vguiPanel)
--	iDraw:SetDrawColor(255,255,255,255)
--	iDraw:DrawString(font, 2,2, "Hello World")
--
	--if iEngine:IsInGame() then
		--local localPlayer = iEntity:GetEntity(iEngine:GetLocalPlayer())
		--for k = 1, iEngine:GetMaxClients() do
		--	local target = iEntity:GetEntity(k)
		--	print(target:Nick(k))
		--end
	--end
--end)

local time = 0
hook.Add("Paint", "TEST", function()
	if (time > CurTime()) then return end
	--iDraw:StartDrawing_ViewRender() -- Surface Draw
		surface.SetDrawColor(255,255,255,255)
		surface.DrawText("Привет Мир!", 2, 2, 'ExampleFont')
		surface.DrawText("Hello World!", 10, 10, 'SchemeFont')
	--iDraw:FinishDrawing_ViewRender()
	time = CurTime() + 5
end)

local i = 0
timer.Create('HelloWorldTimer', 3, 0, function()
	print('Hello World Timer')
	i = i + 1
	if i >= 10 then
		print('HelloWorldTimer remove')
		timer.Remove('HelloWorldTimer') 
	end
end)