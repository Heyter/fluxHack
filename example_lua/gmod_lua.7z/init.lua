include("libs/extensions/hooks.lua")
include("libs/interfaces.lua")
include("libs/wrapper.lua")
include("libs/enums.lua")
include("libs/extensions/timer.lua")

surface.CreateFont('ExampleFont', {
	size = 30,
	outline = true
})

surface.GetSchemeFont('SchemeFont', {
	res = 'ClientScheme', -- garrysmod/resource/ClientScheme.res
	font = 'Default'
})

--print(iEngine:GetScreenSize().x, iEngine:GetScreenSize().y)
--iUtil:LocalPlayer():Nick()

--hook.Add("Paint", "TEST", function(vguiPanel)
--	print(type(vguiPanel), vguiPanel)
--	iDraw:SetDrawColor(255,255,255,255)
--	iDraw:DrawString(font, 2,2, "Hello World")
--
	--for k = 1, iEngine:GetMaxClients() do
	--	local target = iEntity:GetEntity(k)
	--	
	--	if target:IsValid() then
	--		local pos = target:GetPos()
	--		print(target:Nick(), target:GetHealth(), pos.x, pos.y, target:GetIndex())
	--	end
	--end
--end)

hook.Add("PaintSG", "TEST", function()
	iDraw:StartDrawing_ViewRender() -- Surface Draw
		surface.SetDrawColor(255,100,100,255)
		surface.DrawText("Привет Мир!", 100, 100, 'ExampleFont')
		surface.DrawText("Hello World!", 50, 50, 'SchemeFont')
	iDraw:FinishDrawing_ViewRender()
end)

-- Lua supports the following bitwise operators:
-- &: bitwise AND
-- |: bitwise OR
-- ~: bitwise exclusive OR
-- >>: right shift
-- <<: left shift
-- ~: unary bitwise NOT

-- BHOP
hook.Add("CreateMove", "CreateMoveTest", function(cmd, frameTime)
	if iEngine:IsInGame() then
		local ply = LocalPlayer()

		if cmd:IsKeyDown(IN_JUMP) and (ply:GetFlags() & FL_ONGROUND) == 0 and (ply:WaterLevel() & FL_ONGROUND) == 0 and ply:GetMoveType() ~= MOVETYPE_LADDER then
			cmd:RemoveKey(IN_JUMP)
		end
	end
end)

--local i = 0
--timer.Create('HelloWorldTimer', 3, 0, function()
--	print('Hello World Timer')
--	i = i + 1
--	if i >= 10 then
--		print('HelloWorldTimer remove')
--		timer.Remove('HelloWorldTimer') 
--	end
--end)