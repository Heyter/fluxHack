iDraw = Game.Drawing
iEngine = Game.Interfaces:GetEngine()
iEntity = Game.Interfaces:GetEntityList()
iUtil = Game.Utils
iGLua = Game.GLuaStack