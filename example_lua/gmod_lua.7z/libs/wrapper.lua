surface = {}

function ScrW() return iEngine:GetScreenSize().x end
function ScrH() return iEngine:GetScreenSize().y end
function LocalPlayer() -- return iUtil:LocalPlayer()
	return iEntity:GetEntity(iEngine:GetLocalPlayer())
end

local font_cache = {}
function surface.CreateFont(fontName, fontData)
	if not fontName or type(fontData) ~= 'table' then return end
	
	-- since CUtlRBTree might overflow
	font_cache[fontName] = iDraw:CreateFontGlyph(fontData.font or 'Arial', 
		fontData.size or 15, 
		fontData.bold or false, 
		fontData.italic or false, 
		fontData.outline or false, 
		fontData.shadow or false)
end

function surface.GetSchemeFont(fontName, fontData)
	if not fontName or type(fontData) ~= 'table' then return end
	font_cache[fontName] = iUtil:GetSchemeFont(fontData.res or 'ClientScheme', fontData.font or 'Default')
end

function surface.SetDrawColor(r,g,b,a)
	iDraw:SetDrawColor(r or 255, g or 255, b or 255, a or 255)
end

function surface.DrawText(text, x, y, fontName)
	if (not text) then return end
	iDraw:DrawString(type(fontName) == 'number' and fontName or font_cache[fontName] or 0, x or 0, y or 0, text)
end

function table.Count(t)
	local i = 0
	for k in pairs(t) do i = i + 1 end
	return i
end

local curtime_fn = 0
function CurTime()
	iGLua:GetLuaInterface(enum('stack', 'CLIENT'))
    iGLua:PushSpecial(enum('stack', 'SPECIAL_GLOB'))
    iGLua:GetField(-1, "CurTime")
    iGLua:Call(0, 1)
	curtime_fn = iGLua:GetNumber(-1)
    iGLua:Pop(2) -- Curtime, SPECIAL_GLOB
	return curtime_fn
end