enum = {type = {}, stack = {}}

local function add(str)
	enum['type'][str] = (table.Count(enum['type']) -1) + 1
end

add('NIL')
add('BOOL')
add('LIGHTUSERDATA')
add('NUMBER')
add('STRING')
add('TABLE')
add('FUNCTION')
add('USERDATA')
add('THREAD')
add('ENTITY')
add('VECTOR')
add('ANGLE')
add('PHYSOBJ')
add('SAVE')
add('RESTORE')
add('DAMAGEINFO')
add('EFFECTDATA')
add('MOVEDATA')
add('RECIPIENTFILTER')
add('USERCMD')
add('SCRIPTEDVEHICLE')
add('MATERIAL')
add('PANEL')
add('PARTICLE')
add('PARTICLEEMITTER')
add('TEXTURE')
add('USERMSG')
add('CONVAR')
add('IMESH')
add('MATRIX')
add('SOUND')
add('PIXELVISHANDLE')
add('DLIGHT')
add('VIDEO')
add('FILE')
add('COUNT')
add = nil

-- enum - GLuaInterfaceType
enum['stack']['CLIENT'] = 0
enum['stack']['SERVER'] = 1
enum['stack']['MENU'] = 2

-- enum
enum['stack']['SPECIAL_GLOB'] = 0
enum['stack']['SPECIAL_ENV'] = 1
enum['stack']['SPECIAL_REG'] = 2

function enum(tab, type)
	if not enum[tab][type] then return 0 end
	return enum[tab][type]
end