local hooks = {}
hook = {}

function hook.Add(event, id, callback)
	if (type(callback) ~= "function") then
		error( "bad argument #3 to 'Add' (function expected, got " ..type(callback) .. ")", 2)
	end

	hooks[event] = hooks[event] or {}
	hooks[event][id] = callback
end

function hook.Remove(event, id)
	if not hooks[event] then
		error("attempt to remove non-existent hook", 2)
	end

	if not hooks[event] then return end
	hooks[event][id] = nil
end

function hook.Call(event, ...)
	local retn
	for k, v in pairs(hooks[event]) do
		if v ~= nil then retn = v(...) end
	end
	return retn
end

function hook.GetTable()
	return hooks
end