-- lua-flex

timer = {timers = {}}

function timer.Create(identifier, delay, repetitions, callback) -- -1 reps for perma timer
	timer.timers[identifier] = {
		delay = delay,
		time = CurTime() + delay,
		callback = callback,
		reps = repetitions,
	}
end

function timer.Remove(identifier)
	timer.timers[identifier] = nil
end

function timer.Simple(delay, callback)
	timer.Add(CurTime()..math.random(), delay, 1, callback)
end

hook.Add("Paint", "TimerHook", function(vPanel)
	if vPanel ~= 'OverlayPopupPanel' then return end
	
	for k, v in pairs(timer.timers) do
		if v.time <= CurTime() then
			v.callback()
			if v.reps > 0 then
				v.reps = v.reps - 1
				if v.reps == 0 then
					timer.timers[k] = nil
				end
			end
			v.time = CurTime() + v.delay
		end
	end
end)